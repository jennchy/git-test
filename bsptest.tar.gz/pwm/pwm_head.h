#ifndef  __PWM_HEAD_H
#define  __PWM_HEAD_H
#define A  _IO('b',0)
#define B  _IO('b',1)
#define C  _IO('b',2)
#define D  _IO('b',3)
#define E  _IO('b',4)
#endif
