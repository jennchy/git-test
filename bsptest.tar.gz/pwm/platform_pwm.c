#include <linux/kernel.h>
#include <linux/platform_device.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include "pwm_head.h"
MODULE_LICENSE("GPL");
#define PWM_MARJOR 501
#define PWM_MINOR  0
struct class *cls;
dev_t devno;
struct platform_device pdev;
//char buf_write[128]="kernel space";
//char buf_read[128];
char buf_kernel[128];

static int open_pwm(struct inode *inode, struct file *file)
{

	printk("open\n");
	return 0;
}
static  ssize_t read_pwm(struct file *file, char __user *buf, size_t  size, loff_t *loff)
{
	int ret;
	if(size > 128)
		size =128;
	if(size <0)
		return -ENOMEM;
	printk("buf_kernel:%s\n",buf_kernel);
	ret = copy_to_user(buf,buf_kernel,size);
	if(ret !=0)
		return -EINVAL;

	printk("read\n");
	return 0;
}
static ssize_t write_pwm(struct file *file, const char __user *buf, size_t  size, loff_t *loff)
{
	int ret;
	if(size > 128)
		size =128;
	if(size <0)
		return -ENOMEM;
	ret = copy_from_user(buf_kernel,buf,size );
	if(ret !=0)
		return -EINVAL;
	
	printk("buf_kernel:%s\n",buf_kernel);

	printk("write\n");
	return 0;
}
static int release_pwm(struct inode *inode,struct file *file)
{
	printk("close%d\n");
	return 0;
}
static long ioctl_pwm(struct file *file, unsigned int cmd, unsigned long arg)
{
	switch(cmd)
	{
	case A: 

		printk("A\n");
		break;
	case B:

		printk("B\n");
		break;
	case C:

		printk("C\n");
		break;
	case D:
		printk("D\n");
		break;
	case E:
		printk("E\n");
		break;
	default:
		printk("cmd default\n");
		break;
	}
	return 0;
}
struct file_operations fs4412_pwm_fops={
	.owner = THIS_MODULE,
	.open = open_pwm,
	.read = read_pwm,
	.write = write_pwm,
	.release =release_pwm,
	.unlocked_ioctl =ioctl_pwm,
};
int platform_drive_pwm_init(void)
{
	devno = MKDEV(PWM_MARJOR,PWM_MINOR);//
	register_chrdev(PWM_MARJOR,"pwm",&fs4412_pwm_fops);
	cls = class_create(THIS_MODULE,"fs4412pwm");
	device_create(cls,NULL,devno,NULL,"pwm");
	printk("platform_drive_pwm_init ok\n");
	return 0;
}
void platform_drive_pwm_exit(void)
{
	device_destroy(cls,devno);
	class_destroy(cls);
	unregister_chrdev(PWM_MARJOR,"pwm");
	printk("platform_drive_pwm_exit ok\n");
}
module_init(platform_drive_pwm_init);
module_exit(platform_drive_pwm_exit);
